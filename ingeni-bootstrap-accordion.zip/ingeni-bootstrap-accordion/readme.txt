=== Ingeni Bootstrap Accordion ===
Contributors:      Bruce McKinnon, with thanks to Victor Shershnyov
Tags:              block
Tested up to:      6.1
Stable tag:        1.2.1
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

A Gutenberg block for creating Bootstrap 5 accordions. Make sure your theme includes Bootstrap 5 - it is BYO.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/ingeni-bootstrap-accordion` directory, or install the plugin through the WordPress plugins screen directly.

1. Activate the plugin through the 'Plugins' screen in WordPress


== Frequently Asked Questions ==



== Screenshots ==



== Changelog ==

= 1.0.0 = First Release

= 1.1.0 = Updated so that the accordion panels can contain multiple block controls (uses InnerBlocks).

= 1.2.0 = Now allows accordion panels to be open by default
        = Added plugin update checker support.

= 1.2.1 = Extra editor CSS to ensure the accordion item is visible in the block editor.